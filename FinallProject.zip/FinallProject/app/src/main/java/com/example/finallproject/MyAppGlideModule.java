package com.example.finallproject;

import com.bumptech.glide.module.AppGlideModule;

public class MyAppGlideModule extends AppGlideModule {
}
