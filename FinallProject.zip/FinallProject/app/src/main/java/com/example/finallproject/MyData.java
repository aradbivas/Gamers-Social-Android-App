package com.example.finallproject;



public class MyData {

    static String[] nameArray = {"Fifa 21", "Halo", "Warzone", "Among Us", "Sims","Angry Birds","Fruit Ninja","Temple Run","GTA","Fortnite", "Subway Surfer","Worms"};

    static Integer[] drawableArray = {R.drawable.fifa21, R.drawable.halo, R.drawable.warzone,
            R.drawable.amongus, R.drawable.sims,R.drawable.angrybirds,R.drawable.fruitninja,R.drawable.templerun,R.drawable.gta ,R.drawable.fortnite,R.drawable.subwaysurfer,
            R.drawable.worms};

    static Integer[] id_ = {0, 1, 2, 3, 4,5,6,7,8,9,10,11};
}
