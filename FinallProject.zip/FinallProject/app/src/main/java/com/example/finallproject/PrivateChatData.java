package com.example.finallproject;

public class PrivateChatData {

    String myUserName;
    String ChatUserName;
    Boolean OpenedChat = false;

    public String getMyUserName() {
        return myUserName;
    }

    public void setMyUserName(String myUserName) {
        this.myUserName = myUserName;
    }

    public String getChatUserName() {
        return ChatUserName;
    }

    public void setChatUserName(String chatUserName) {
        ChatUserName = chatUserName;
    }


}
